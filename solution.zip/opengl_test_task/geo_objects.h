#pragma once
#include<windows.h>

class Geometric_Object;
class Hexagon;


struct ListNode
{
    Geometric_Object* mGeomObj/* = nullptr*/;
	ListNode* next/* = nullptr*/;
public:
    ListNode() : mGeomObj(nullptr), next(nullptr) {};
    ListNode(Geometric_Object* mGeomObj_) : mGeomObj(mGeomObj_), next(nullptr) {};
    ListNode(Geometric_Object* mGeomObj_, ListNode* next_) : mGeomObj(mGeomObj_), next(next_) {};
};


class Geometric_Object
{
protected:
    float* vertices;
    int vertices_size;
public:
    virtual void draw_object()
    {
        glBufferData(GL_ARRAY_BUFFER, vertices_size, vertices, GL_STATIC_DRAW);
        Sleep(200);
    }
    float* get_vertices() { return vertices; }
    int get_vertices_size() { return vertices_size; }
};


class Hexagon : public Geometric_Object
{
public:
    Hexagon()
    {
         vertices = new float[6*6*5]{
            -0.5f, -0.5f, -0.5f,  0.0f, 0.0f,
             0.5f, -0.5f, -0.5f,  1.0f, 0.0f,
             0.5f,  0.5f, -0.5f,  1.0f, 1.0f,
             0.5f,  0.5f, -0.5f,  1.0f, 1.0f,
            -0.5f,  0.5f, -0.5f,  0.0f, 1.0f,
            -0.5f, -0.5f, -0.5f,  0.0f, 0.0f,

            -0.5f, -0.5f,  0.5f,  0.0f, 0.0f,
             0.5f, -0.5f,  0.5f,  1.0f, 0.0f,
             0.5f,  0.5f,  0.5f,  1.0f, 1.0f,
             0.5f,  0.5f,  0.5f,  1.0f, 1.0f,
            -0.5f,  0.5f,  0.5f,  0.0f, 1.0f,
            -0.5f, -0.5f,  0.5f,  0.0f, 0.0f,

            -0.5f,  0.5f,  0.5f,  1.0f, 0.0f,
            -0.5f,  0.5f, -0.5f,  1.0f, 1.0f,
            -0.5f, -0.5f, -0.5f,  0.0f, 1.0f,
            -0.5f, -0.5f, -0.5f,  0.0f, 1.0f,
            -0.5f, -0.5f,  0.5f,  0.0f, 0.0f,
            -0.5f,  0.5f,  0.5f,  1.0f, 0.0f,

             0.5f,  0.5f,  0.5f,  1.0f, 0.0f,
             0.5f,  0.5f, -0.5f,  1.0f, 1.0f,
             0.5f, -0.5f, -0.5f,  0.0f, 1.0f,
             0.5f, -0.5f, -0.5f,  0.0f, 1.0f,
             0.5f, -0.5f,  0.5f,  0.0f, 0.0f,
             0.5f,  0.5f,  0.5f,  1.0f, 0.0f,

            -0.5f, -0.5f, -0.5f,  0.0f, 1.0f,
             0.5f, -0.5f, -0.5f,  1.0f, 1.0f,
             0.5f, -0.5f,  0.5f,  1.0f, 0.0f,
             0.5f, -0.5f,  0.5f,  1.0f, 0.0f,
            -0.5f, -0.5f,  0.5f,  0.0f, 0.0f,
            -0.5f, -0.5f, -0.5f,  0.0f, 1.0f,

            -0.5f,  0.5f, -0.5f,  0.0f, 1.0f,
             0.5f,  0.5f, -0.5f,  1.0f, 1.0f,
             0.5f,  0.5f,  0.5f,  1.0f, 0.0f,
             0.5f,  0.5f,  0.5f,  1.0f, 0.0f,
            -0.5f,  0.5f,  0.5f,  0.0f, 0.0f,
            -0.5f,  0.5f, -0.5f,  0.0f, 1.0f
        };
        //vertices = _vertices;
        vertices_size = 6*6*5*4;
    }
};

class Pyramide : public Geometric_Object
{
public:
    Pyramide()
    {
        vertices = new float[6*3*5]{
           -0.5f, -0.5f, -0.5f,  0.0f, 0.0f, // 1
            0.5f, -0.5f, -0.5f,  1.0f, 0.0f, // 2
            0.0f,  0.5f,  0.0f,  1.0f, 1.0f, // 3 

           -0.5f, -0.5f,  0.5f,  0.0f, 0.0f,
            0.5f, -0.5f,  0.5f,  1.0f, 0.0f,
            0.0f,  0.5f,  0.0f,  1.0f, 1.0f,

           -0.5f, -0.5f, -0.5f,  1.0f, 0.0f,
           -0.5f, -0.5f,  0.5f,  1.0f, 1.0f,
            0.0f,  0.5f,  0.0f,  0.0f, 1.0f,

            0.5f, -0.5f, -0.5f,  1.0f, 0.0f,
            0.5f, -0.5f,  0.5f,  1.0f, 1.0f,
            0.0f,  0.5f,  0.0f,  0.0f, 1.0f,

           -0.5f, -0.5f, -0.5f,  0.0f, 0.0f,
            0.5f, -0.5f, -0.5f,  1.0f, 0.0f,
            0.5f, -0.5f,  0.5f,  1.0f, 1.0f,
            0.5f, -0.5f,  0.5f,  1.0f, 1.0f,
           -0.5f, -0.5f,  0.5f,  0.0f, 1.0f,
           -0.5f, -0.5f, -0.5f,  0.0f, 0.0f,
        };
        //vertices = _vertices;
        vertices_size = 6 * 3 * 5 * 4;
    }
};

class Wedge : public Geometric_Object
{
public:
    Wedge()
    {
        vertices = new float[4*6*5]{
           -0.5f, -0.5f, -0.5f,  0.0f, 0.0f, // 1
            0.5f, -0.5f, -0.5f,  1.0f, 0.0f, // 2
            0.0f,  0.5f, -0.5f,  1.0f, 1.0f, // 3 

           -0.5f, -0.5f,  0.5f,  0.0f, 0.0f,
            0.5f, -0.5f,  0.5f,  1.0f, 0.0f,
            0.0f,  0.5f,  0.5f,  1.0f, 1.0f,

           -0.5f, -0.5f, -0.5f,  1.0f, 0.0f,
           -0.5f, -0.5f,  0.5f,  1.0f, 1.0f,
            0.0f,  0.5f,  0.5f,  0.0f, 1.0f,
            0.0f,  0.5f,  0.5f,  0.0f, 1.0f,
            0.0f,  0.5f, -0.5f,  1.0f, 1.0f,
           -0.5f, -0.5f, -0.5f,  1.0f, 0.0f,

            0.5f, -0.5f, -0.5f,  1.0f, 0.0f,
            0.5f, -0.5f,  0.5f,  1.0f, 1.0f,
            0.0f,  0.5f,  0.5f,  0.0f, 1.0f,
            0.0f,  0.5f,  0.5f,  0.0f, 1.0f,
            0.0f,  0.5f, -0.5f,  1.0f, 1.0f,
            0.5f, -0.5f, -0.5f,  1.0f, 0.0f,

           -0.5f, -0.5f, -0.5f,  0.0f, 0.0f,
            0.5f, -0.5f, -0.5f,  1.0f, 0.0f,
            0.5f, -0.5f,  0.5f,  1.0f, 1.0f,
            0.5f, -0.5f,  0.5f,  1.0f, 1.0f,
           -0.5f, -0.5f,  0.5f,  0.0f, 1.0f,
           -0.5f, -0.5f, -0.5f,  0.0f, 0.0f,
        };
        //vertices = _vertices;
        vertices_size = 4 * 6 * 5 * 4;
    }
};
